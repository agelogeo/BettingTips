function AltToday() {
  
  var Match = function(date,time,league,home_team,away_team,odds,tip,home_score,away_score,gotcha){
               this.date=date;
               this.time = time;
               this.league = league;
               this.home_team = home_team;
               this.away_team = away_team;
               this.odds = odds;
               this.tip = tip;
               this.home_score = home_score;
               this.away_score = away_score;
               this.gotcha = gotcha;
  }
  
  var fetchString="https://extrabetting8.blogspot.gr/"
  var response = UrlFetchApp.fetch(fetchString);
  
  var matches = [];

  var doc = Xml.parse(response.getBlob().getDataAsString(),true);
  var b = doc.html.body;
  

  var date = b[1].getElements("p")[2].getElement("strong").getElement("span").getElement("span").getText();
  date = date.replace(/ /g,'');
  date = date.slice(6)+'-'+date.slice(3,5)+'-'+date.slice(0,2);
    
  for(var i=0;i<2;i++){
    var table = b[1].getElements("table")[i].tbody;
    
    var rows = [];  
    var trs = table.getElements("tr");
    
    for(var r=2;r<trs.length-1;r=r+2){
      var tds = trs[r].getElements("td");
      
      var time = tds[0];  
      while(time.getElement()!=null){
        time = time.getElement();
      }   
      time = time.getText();
      time = time.trim();
      
      var home_team = tds[2];  
      while(home_team.getElement()!=null){
        home_team = home_team.getElement();
      }   
      home_team = home_team.getText();
      if(home_team.charAt(0)=='�')
        home_team=home_team.slice(1);
      
      var away_team = tds[3];  
      while(away_team.getElement()!=null){
        away_team = away_team.getElement();
      }   
      away_team = away_team.getText();
      if(away_team.charAt(0)=='�')
        away_team=away_team.slice(1);
      
      var tip = tds[4];  
      while(tip.getElement()!=null){
        tip = tip.getElement();
      }   
      tip = tip.getText();
      tip = tip.substr(0,1).toUpperCase().concat(tip.substr(1));
      
      tds = trs[r+1].getElements("td");
      
      var league = tds[0];  
      while(league.getElement()!=null){
        league = league.getElement();
      }   
      league = league.getText();
      
      var odds = tds[1];  
      while(odds.getElement()!=null){
        odds = odds.getElement();
      }   
      odds = odds.getText();    
      
      var home_score = "0";
      var away_score = "0";
      var gotcha = "yet";
      
      
      
      
      var match = new Match(date,time,league,home_team,away_team,odds,tip,home_score,away_score,gotcha);
      matches.push(match);
        
    }
       
  }
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheets()[2];
  var lastRow = sheet.getLastRow();
  for(var i=lastRow; i>1; i--){
    sheet.deleteRow(i);   
  }
  
  for(var i=0; i<matches.length; i++){    
    sheet.appendRow([matches[i].date,matches[i].league,matches[i].time,matches[i].home_team,matches[i].away_team,matches[i].home_score,matches[i].away_score,matches[i].odds,matches[i].tip,matches[i].gotcha]);
  }
  
  var range = sheet.getRange(1, 1, sheet.getMaxRows(), sheet.getMaxColumns());
  range.setNumberFormat('@');
  
 
  
}




///**
// * Automatically sorts the 1st column (not the header row) Ascending.����
// */
//function onEdit(event){
//  var sheet = event.source.getActiveSheet();
//  var editedCell = sheet.getActiveCell();
//
//  var columnToSortBy = 1;
//  var tableRange = "A2:T200"; // What to sort.
//
//  if(editedCell.getColumn() == columnToSortBy && sheet.getName()!="stats"){   
//    var range = sheet.getRange(tableRange);
//    range.sort( { column : columnToSortBy, ascending: false } );
//  }
//}