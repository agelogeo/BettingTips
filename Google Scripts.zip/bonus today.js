function BonusToday() {
  
  var Match = function(date,time,league,home_team,away_team,odds,tip,home_score,away_score,gotcha){
               this.date=date;
               this.time = time;
               this.league = league;
               this.home_team = home_team;
               this.away_team = away_team;
               this.odds = odds;
               this.tip = tip;
               this.home_score = home_score;
               this.away_score = away_score;
               this.gotcha = gotcha;
  }
  
  var fetchString="https://bettingtipsvip1.blogspot.gr/"
  var response = UrlFetchApp.fetch(fetchString);

  var doc = Xml.parse(response.getBlob().getDataAsString(),true);
  var b = doc.html.body;
  var table = b.table.tbody;
  
  

  var rows = [];
  var matches = [];
  var trs = table.getElements("tr");
  
  var date = trs[2].getElements("td")[2].getElement("span").getElement("span").getElement("strong").getText();
  date = date.replace(/ /g,'');
  date = date.slice(6)+'-'+date.slice(3,5)+'-'+date.slice(0,2);
  date = date.replace(/\//g,'-');
  
  var r = 3;
  while(trs[r].getElements("td")[0].getElement()!=null){
    var tds = trs[r].getElements("td");
      
      var time = tds[0];  
      while(time.getElement()!=null){
        time = time.getElement();
      }   
      time = time.getText();
      
      var home_team = tds[2];  
      while(home_team.getElement()!=null){
        home_team = home_team.getElement();
      }   
      home_team = home_team.getText();
      if(home_team.charAt(0)=='�')
        home_team=home_team.slice(1);
      
      var away_team = tds[3];  
      while(away_team.getElement()!=null){
        away_team = away_team.getElement();
      }   
      away_team = away_team.getText();
      if(away_team.charAt(0)=='�')
        away_team=away_team.slice(1);
      
      var tip = tds[4];  
      while(tip.getElement()!=null){
        tip = tip.getElement();
      }   
      tip = tip.getText();
    tip = tip.substr(0,1).toUpperCase().concat(tip.substr(1));
      
      tds = trs[r+1].getElements("td");
      
      var league = tds[0];  
      while(league.getElement()!=null){
        league = league.getElement();
      }   
      league = league.getText();
      
      var odds = tds[1];  
      while(odds.getElement()!=null){
        odds = odds.getElement();
      }   
      odds = odds.getText();    
      
      var home_score = "0";
      var away_score = "0";
      var gotcha = "yet";
      
      
      
      
      var match = new Match(date,time,league,home_team,away_team,odds,tip,home_score,away_score,gotcha);
      matches.push(match);
    
    r=r+2;
    
  }
  
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheets()[4];
  var lastRow = sheet.getLastRow();
  for(var i=lastRow; i>1; i--){
    sheet.deleteRow(i);   
  }
  
  for(var i=0; i<matches.length; i++){    
    sheet.appendRow([matches[i].date,matches[i].league,matches[i].time,matches[i].home_team,matches[i].away_team,matches[i].home_score,matches[i].away_score,matches[i].odds,matches[i].tip,matches[i].gotcha]);
  }
  
  var range = sheet.getRange(1, 1, sheet.getMaxRows(), sheet.getMaxColumns());
  range.setNumberFormat('@');
  
 
  
}



///**
// * Automatically sorts the 1st column (not the header row) Ascending.����
// */
//function onEdit(event){
//  var sheet = event.source.getActiveSheet();
//  var editedCell = sheet.getActiveCell();
//
//  var columnToSortBy = 1;
//  var tableRange = "A2:T200"; // What to sort.
//
//  if(editedCell.getColumn() == columnToSortBy && sheet.getName()!="stats"){   
//    var range = sheet.getRange(tableRange);
//    range.sort( { column : columnToSortBy, ascending: false } );
//  }
//}